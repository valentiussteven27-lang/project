// Snake Game — by Steven Valentius Young

const canvas = document.getElementById('snakeCanvas');
const ctx = canvas.getContext('2d');

const GRID = 20;
const COLS = canvas.width / GRID;
const ROWS = canvas.height / GRID;

let snake, dir, nextDir, food, score, bestScore, level, speed;
let gameLoop = null;
let gameState = 'idle';

const startBtn  = document.getElementById('startBtn');
const pauseBtn  = document.getElementById('pauseBtn');
const scoreDisp = document.getElementById('scoreDisplay');
const bestDisp  = document.getElementById('bestDisplay');
const levelDisp = document.getElementById('levelDisplay');

bestScore = parseInt(localStorage.getItem('snakeBest') || '0');
if (bestDisp) bestDisp.textContent = bestScore;

// ---- Theme colors (green snake) ----
const C_HEAD   = '#22c55e';
const C_BODY   = '#16a34a';
const C_FOOD   = '#ef4444';
const C_GRID   = '#0d1f0d';
const C_BG     = '#050f05';

function initGame() {
  snake    = [{x:12,y:12},{x:11,y:12},{x:10,y:12}];
  dir      = {x:1, y:0};
  nextDir  = {x:1, y:0};
  score    = 0;
  level    = 1;
  speed    = 150;
  if (scoreDisp) scoreDisp.textContent = 0;
  if (levelDisp) levelDisp.textContent = 1;
  placeFood();
}

function placeFood() {
  let pos;
  do {
    pos = {x: Math.floor(Math.random()*COLS), y: Math.floor(Math.random()*ROWS)};
  } while (snake.some(s=>s.x===pos.x&&s.y===pos.y));
  food = pos;
}

function update() {
  dir = {...nextDir};
  const head = {x: snake[0].x+dir.x, y: snake[0].y+dir.y};

  if (head.x<0||head.x>=COLS||head.y<0||head.y>=ROWS||snake.some(s=>s.x===head.x&&s.y===head.y)) {
    endGame(); return;
  }

  snake.unshift(head);

  if (head.x===food.x && head.y===food.y) {
    score += 10 * level;
    if (scoreDisp) scoreDisp.textContent = score;

    if (score > bestScore) {
      bestScore = score;
      if (bestDisp) bestDisp.textContent = bestScore;
      localStorage.setItem('snakeBest', bestScore);
    }

    const newLevel = Math.floor(score/50)+1;
    if (newLevel > level) {
      level = newLevel;
      if (levelDisp) levelDisp.textContent = level;
      speed = Math.max(55, 150-(level-1)*15);
      restartLoop();
    }
    placeFood();
  } else {
    snake.pop();
  }
  draw();
}

function draw() {
  ctx.fillStyle = C_BG;
  ctx.fillRect(0,0,canvas.width,canvas.height);

  // Grid
  ctx.strokeStyle = C_GRID;
  ctx.lineWidth = 0.5;
  for (let x=0; x<=canvas.width; x+=GRID) {
    ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,canvas.height); ctx.stroke();
  }
  for (let y=0; y<=canvas.height; y+=GRID) {
    ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(canvas.width,y); ctx.stroke();
  }

  // Food
  const fx = food.x*GRID+GRID/2, fy = food.y*GRID+GRID/2;
  const glow = ctx.createRadialGradient(fx,fy,0,fx,fy,GRID);
  glow.addColorStop(0,'rgba(239,68,68,0.3)');
  glow.addColorStop(1,'transparent');
  ctx.fillStyle = glow;
  ctx.beginPath(); ctx.arc(fx,fy,GRID,0,Math.PI*2); ctx.fill();

  ctx.fillStyle = C_FOOD;
  ctx.shadowColor = '#ef4444';
  ctx.shadowBlur = 14;
  ctx.beginPath(); ctx.arc(fx,fy,GRID/2-2,0,Math.PI*2); ctx.fill();
  ctx.shadowBlur = 0;

  // Snake
  snake.forEach((seg,i) => {
    if (i===0) {
      ctx.fillStyle = C_HEAD;
      ctx.shadowColor = '#22c55e';
      ctx.shadowBlur = 16;
    } else {
      const r = i/snake.length;
      ctx.fillStyle = `hsl(${142-r*15}, ${80-r*20}%, ${45-r*20}%)`;
      ctx.shadowBlur = 0;
    }
    ctx.beginPath();
    ctx.roundRect(seg.x*GRID+1,seg.y*GRID+1,GRID-2,GRID-2,i===0?5:3);
    ctx.fill();

    if (i===0) {
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#fff';
      const eo=4, es=3;
      let ex1,ey1,ex2,ey2;
      const x=seg.x*GRID, y=seg.y*GRID;
      if (dir.x===1)       {ex1=x+GRID-eo;ey1=y+eo;    ex2=x+GRID-eo;ey2=y+GRID-eo;}
      else if (dir.x===-1) {ex1=x+eo;     ey1=y+eo;    ex2=x+eo;     ey2=y+GRID-eo;}
      else if (dir.y===-1) {ex1=x+eo;     ey1=y+eo;    ex2=x+GRID-eo;ey2=y+eo;}
      else                 {ex1=x+eo;     ey1=y+GRID-eo;ex2=x+GRID-eo;ey2=y+GRID-eo;}
      ctx.beginPath(); ctx.arc(ex1,ey1,es,0,Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.arc(ex2,ey2,es,0,Math.PI*2); ctx.fill();
      ctx.fillStyle='#000';
      ctx.beginPath(); ctx.arc(ex1+0.5,ey1+0.5,1.5,0,Math.PI*2); ctx.fill();
      ctx.beginPath(); ctx.arc(ex2+0.5,ey2+0.5,1.5,0,Math.PI*2); ctx.fill();
    }
  });
  ctx.shadowBlur = 0;

  if (gameState==='paused') {
    ctx.fillStyle='rgba(0,0,0,0.6)';
    ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.fillStyle='#22c55e';
    ctx.font='bold 34px "Press Start 2P", monospace';
    ctx.textAlign='center'; ctx.textBaseline='middle';
    ctx.fillText('PAUSED',canvas.width/2,canvas.height/2-18);
    ctx.font='12px "Exo 2", sans-serif';
    ctx.fillStyle='#a3e6a3';
    ctx.fillText('Tekan SPACE atau tombol Pause untuk lanjut',canvas.width/2,canvas.height/2+22);
  }
}

function drawIdle() {
  ctx.fillStyle=C_BG; ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.strokeStyle=C_GRID; ctx.lineWidth=0.5;
  for (let x=0;x<=canvas.width;x+=GRID){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,canvas.height);ctx.stroke();}
  for (let y=0;y<=canvas.height;y+=GRID){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(canvas.width,y);ctx.stroke();}

  ctx.textAlign='center'; ctx.textBaseline='middle';
  ctx.fillStyle='#22c55e';
  ctx.font='bold 28px "Press Start 2P", monospace';
  ctx.shadowColor='#22c55e'; ctx.shadowBlur=20;
  ctx.fillText('SNAKE GAME',canvas.width/2,canvas.height/2-55);
  ctx.shadowBlur=0;
  ctx.font='13px "Exo 2", sans-serif';
  ctx.fillStyle='#a3e6a3';
  ctx.fillText('by Steven Valentius Young',canvas.width/2,canvas.height/2-15);
  ctx.fillStyle='#4ade80';
  ctx.fillText('Tekan MULAI untuk bermain',canvas.width/2,canvas.height/2+20);
  ctx.fillStyle='#22c55e';
  ctx.fillText('Arrow Keys / WASD untuk kontrol',canvas.width/2,canvas.height/2+50);

  // Demo snake
  [{x:12,y:18},{x:11,y:18},{x:10,y:18},{x:9,y:18},{x:8,y:18}].forEach((s,i)=>{
    ctx.fillStyle = i===0 ? C_HEAD : C_BODY;
    ctx.shadowColor = i===0 ? '#22c55e' : 'transparent';
    ctx.shadowBlur = i===0 ? 8 : 0;
    ctx.beginPath(); ctx.roundRect(s.x*GRID+1,s.y*GRID+1,GRID-2,GRID-2,4); ctx.fill();
    ctx.shadowBlur=0;
  });
  ctx.fillStyle=C_FOOD; ctx.shadowColor='#ef4444'; ctx.shadowBlur=12;
  ctx.beginPath(); ctx.arc(14*GRID+GRID/2,18*GRID+GRID/2,GRID/2-3,0,Math.PI*2); ctx.fill();
  ctx.shadowBlur=0;
}

function drawGameOver() {
  ctx.fillStyle='rgba(0,0,0,0.75)'; ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.textAlign='center'; ctx.textBaseline='middle';

  ctx.fillStyle='#ef4444';
  ctx.font='bold 30px "Press Start 2P", monospace';
  ctx.shadowColor='#ef4444'; ctx.shadowBlur=20;
  ctx.fillText('GAME OVER',canvas.width/2,canvas.height/2-65);
  ctx.shadowBlur=0;

  ctx.fillStyle='#fff';
  ctx.font='bold 22px "Exo 2", sans-serif';
  ctx.fillText('Score: '+score,canvas.width/2,canvas.height/2-15);
  ctx.fillText('Best: '+bestScore,canvas.width/2,canvas.height/2+20);

  if (score>0 && score===bestScore) {
    ctx.fillStyle='#f59e0b';
    ctx.font='bold 18px "Press Start 2P", monospace';
    ctx.shadowColor='#f59e0b'; ctx.shadowBlur=12;
    ctx.fillText('NEW BEST!',canvas.width/2,canvas.height/2+60);
    ctx.shadowBlur=0;
  }

  ctx.fillStyle='#a3e6a3';
  ctx.font='13px "Exo 2", sans-serif';
  ctx.fillText('Tekan MULAI untuk main lagi',canvas.width/2,canvas.height/2+90);
}

function startLoop()   { if (gameLoop) clearInterval(gameLoop); gameLoop=setInterval(update,speed); }
function restartLoop() { if (gameLoop) clearInterval(gameLoop); gameLoop=setInterval(update,speed); }

function startGame() {
  initGame();
  gameState='playing';
  startBtn.innerHTML='<i class="bi bi-arrow-counterclockwise me-1"></i>RESTART';
  pauseBtn.disabled=false;
  pauseBtn.innerHTML='<i class="bi bi-pause-fill"></i>';
  startLoop();
}

function endGame() {
  clearInterval(gameLoop); gameLoop=null;
  gameState='over';
  drawGameOver();
  startBtn.innerHTML='<i class="bi bi-play-fill me-1"></i>MULAI';
  pauseBtn.disabled=true;
}

function togglePause() {
  if (gameState==='playing') {
    gameState='paused'; clearInterval(gameLoop); gameLoop=null;
    pauseBtn.innerHTML='<i class="bi bi-play-fill"></i>';
    draw();
  } else if (gameState==='paused') {
    gameState='playing';
    pauseBtn.innerHTML='<i class="bi bi-pause-fill"></i>';
    startLoop();
  }
}

// Controls
document.addEventListener('keydown', e => {
  if ([' ','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)) e.preventDefault();
  if (e.key===' ') { if (gameState==='playing'||gameState==='paused') togglePause(); return; }
  if (gameState!=='playing') return;
  const moves={'ArrowUp':{x:0,y:-1},'ArrowDown':{x:0,y:1},'ArrowLeft':{x:-1,y:0},'ArrowRight':{x:1,y:0},
    'w':{x:0,y:-1},'s':{x:0,y:1},'a':{x:-1,y:0},'d':{x:1,y:0},
    'W':{x:0,y:-1},'S':{x:0,y:1},'A':{x:-1,y:0},'D':{x:1,y:0}};
  const nd=moves[e.key]; if (!nd) return;
  if (nd.x!==-dir.x||nd.y!==-dir.y) nextDir=nd;
});

document.getElementById('btnUp')?.addEventListener('click',()=>{ if(gameState==='playing'&&dir.y!==1) nextDir={x:0,y:-1}; });
document.getElementById('btnDown')?.addEventListener('click',()=>{ if(gameState==='playing'&&dir.y!==-1) nextDir={x:0,y:1}; });
document.getElementById('btnLeft')?.addEventListener('click',()=>{ if(gameState==='playing'&&dir.x!==1) nextDir={x:-1,y:0}; });
document.getElementById('btnRight')?.addEventListener('click',()=>{ if(gameState==='playing'&&dir.x!==-1) nextDir={x:1,y:0}; });

startBtn?.addEventListener('click', startGame);
pauseBtn?.addEventListener('click', togglePause);

drawIdle();
