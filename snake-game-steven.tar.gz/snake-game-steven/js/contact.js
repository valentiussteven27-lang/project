// Contact page JavaScript

// =====================
// Character counter for textarea
// =====================
const messageInput = document.getElementById('inputMessage');
const charCount = document.getElementById('charCount');

if (messageInput) {
  messageInput.addEventListener('input', () => {
    const len = messageInput.value.length;
    charCount.textContent = `${len} / 500 karakter`;
    if (len > 500) {
      charCount.style.color = '#ef4444';
    } else {
      charCount.style.color = '';
    }
  });
}

// =====================
// Form validation helpers
// =====================
function showError(inputId, errorId, message) {
  const input = document.getElementById(inputId);
  const error = document.getElementById(errorId);
  input.classList.add('is-invalid');
  input.classList.remove('is-valid');
  if (error) error.textContent = message;
}

function showValid(inputId) {
  const input = document.getElementById(inputId);
  input.classList.remove('is-invalid');
  input.classList.add('is-valid');
}

function clearValidation(inputId, errorId) {
  const input = document.getElementById(inputId);
  const error = document.getElementById(errorId);
  input.classList.remove('is-invalid', 'is-valid');
  if (error) error.textContent = '';
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// =====================
// Real-time validation on blur
// =====================
const fields = [
  { id: 'inputName', errorId: 'nameError' },
  { id: 'inputEmail', errorId: 'emailError' },
  { id: 'inputSubject', errorId: 'subjectError' },
  { id: 'inputMessage', errorId: 'messageError' },
];

fields.forEach(({ id, errorId }) => {
  const el = document.getElementById(id);
  if (!el) return;
  el.addEventListener('blur', () => validateField(id, errorId));
  el.addEventListener('input', () => {
    if (el.classList.contains('is-invalid')) validateField(id, errorId);
  });
});

function validateField(id, errorId) {
  const el = document.getElementById(id);
  if (!el) return true;
  const val = el.value.trim();

  if (id === 'inputName') {
    if (!val) { showError(id, errorId, 'Nama lengkap wajib diisi.'); return false; }
    if (val.length < 2) { showError(id, errorId, 'Nama minimal 2 karakter.'); return false; }
  }
  if (id === 'inputEmail') {
    if (!val) { showError(id, errorId, 'Email wajib diisi.'); return false; }
    if (!isValidEmail(val)) { showError(id, errorId, 'Format email tidak valid.'); return false; }
  }
  if (id === 'inputSubject') {
    if (!val) { showError(id, errorId, 'Subjek wajib diisi.'); return false; }
    if (val.length < 4) { showError(id, errorId, 'Subjek minimal 4 karakter.'); return false; }
  }
  if (id === 'inputMessage') {
    if (!val) { showError(id, errorId, 'Pesan wajib diisi.'); return false; }
    if (val.length < 10) { showError(id, errorId, 'Pesan minimal 10 karakter.'); return false; }
    if (val.length > 500) { showError(id, errorId, 'Pesan maksimal 500 karakter.'); return false; }
  }

  showValid(id);
  return true;
}

// =====================
// Form submit handler
// =====================
const form = document.getElementById('contactForm');
const submitBtn = document.getElementById('submitBtn');
const btnText = document.getElementById('btnText');
const btnLoading = document.getElementById('btnLoading');
const successAlert = document.getElementById('successAlert');

if (form) {
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    // Validate all fields
    const validName    = validateField('inputName', 'nameError');
    const validEmail   = validateField('inputEmail', 'emailError');
    const validSubject = validateField('inputSubject', 'subjectError');
    const validMessage = validateField('inputMessage', 'messageError');

    if (!validName || !validEmail || !validSubject || !validMessage) return;

    // Show loading
    submitBtn.disabled = true;
    btnText.classList.add('d-none');
    btnLoading.classList.remove('d-none');

    // Simulate sending (no real API)
    setTimeout(() => {
      // Hide loading, show success
      submitBtn.disabled = false;
      btnText.classList.remove('d-none');
      btnLoading.classList.add('d-none');

      successAlert.classList.remove('d-none');
      successAlert.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

      // Reset form
      form.reset();
      fields.forEach(({ id, errorId }) => clearValidation(id, errorId));
      if (charCount) charCount.textContent = '0 / 500 karakter';

      // Hide success alert after 6 seconds
      setTimeout(() => {
        successAlert.classList.add('d-none');
      }, 6000);
    }, 1500);
  });
}
