// Landing page JS — Snake Game Promo Site by Steven Valentius Young

// =====================
// Scroll fade-in
// =====================
const fadeEls = document.querySelectorAll('.fade-in');
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
fadeEls.forEach(el => observer.observe(el));

// Trigger hero elements immediately
setTimeout(() => {
  document.querySelectorAll('.hero-section .fade-in').forEach(el => el.classList.add('visible'));
}, 80);

// =====================
// Animated counters in stats section
// =====================
function animateCounter(el, target, duration = 1600) {
  let start = 0;
  const step = target / (duration / 16);
  const timer = setInterval(() => {
    start += step;
    if (start >= target) {
      el.textContent = target.toLocaleString('id-ID');
      clearInterval(timer);
    } else {
      el.textContent = Math.floor(start).toLocaleString('id-ID');
    }
  }, 16);
}

const statEls = document.querySelectorAll('.score-ticker[data-target]');
let counterDone = false;
const statObs = new IntersectionObserver((entries) => {
  if (entries[0].isIntersecting && !counterDone) {
    counterDone = true;
    statEls.forEach(el => animateCounter(el, parseInt(el.getAttribute('data-target'))));
    statObs.disconnect();
  }
}, { threshold: 0.3 });
if (statEls.length) statObs.observe(statEls[0].closest('section'));

// =====================
// Hero Preview Canvas — auto-playing mini snake demo
// =====================
const previewCanvas = document.getElementById('previewCanvas');
if (previewCanvas) {
  const pctx = previewCanvas.getContext('2d');
  const PGRID = 14;
  const PCOLS = Math.floor(previewCanvas.width / PGRID);
  const PROWS = Math.floor(previewCanvas.height / PGRID);

  let pSnake = [{x:10,y:10},{x:9,y:10},{x:8,y:10},{x:7,y:10}];
  let pFood = {x:15, y:10};
  let pDir = {x:1, y:0};
  let pScore = 0;

  // AI: simple pathfinding toward food
  function getNextDir() {
    const head = pSnake[0];
    const dx = pFood.x - head.x;
    const dy = pFood.y - head.y;
    const candidates = [];

    if (Math.abs(dx) >= Math.abs(dy)) {
      candidates.push(dx > 0 ? {x:1,y:0} : {x:-1,y:0});
      candidates.push(dy > 0 ? {x:0,y:1} : {x:0,y:-1});
    } else {
      candidates.push(dy > 0 ? {x:0,y:1} : {x:0,y:-1});
      candidates.push(dx > 0 ? {x:1,y:0} : {x:-1,y:0});
    }
    // Add fallback directions
    [{x:1,y:0},{x:-1,y:0},{x:0,y:1},{x:0,y:-1}].forEach(d => {
      if (!candidates.find(c => c.x===d.x && c.y===d.y)) candidates.push(d);
    });

    for (const d of candidates) {
      if (d.x === -pDir.x && d.y === -pDir.y) continue; // no reverse
      const nx = head.x + d.x;
      const ny = head.y + d.y;
      if (nx < 0 || nx >= PCOLS || ny < 0 || ny >= PROWS) continue;
      if (pSnake.some(s => s.x === nx && s.y === ny)) continue;
      return d;
    }
    return pDir;
  }

  function placePFood() {
    let pos;
    do {
      pos = {x: Math.floor(Math.random()*PCOLS), y: Math.floor(Math.random()*PROWS)};
    } while (pSnake.some(s=>s.x===pos.x&&s.y===pos.y));
    pFood = pos;
  }

  function drawPreview() {
    // BG
    pctx.fillStyle = '#050f05';
    pctx.fillRect(0, 0, previewCanvas.width, previewCanvas.height);

    // Grid
    pctx.strokeStyle = '#0d1f0d';
    pctx.lineWidth = 0.5;
    for (let x=0; x<=previewCanvas.width; x+=PGRID) {
      pctx.beginPath(); pctx.moveTo(x,0); pctx.lineTo(x,previewCanvas.height); pctx.stroke();
    }
    for (let y=0; y<=previewCanvas.height; y+=PGRID) {
      pctx.beginPath(); pctx.moveTo(0,y); pctx.lineTo(previewCanvas.width,y); pctx.stroke();
    }

    // Food glow
    const fx = pFood.x*PGRID+PGRID/2, fy = pFood.y*PGRID+PGRID/2;
    pctx.fillStyle = '#ef4444';
    pctx.shadowColor = '#ef4444';
    pctx.shadowBlur = 10;
    pctx.beginPath();
    pctx.arc(fx, fy, PGRID/2-2, 0, Math.PI*2);
    pctx.fill();
    pctx.shadowBlur = 0;

    // Snake
    pSnake.forEach((seg, i) => {
      const ratio = i / pSnake.length;
      pctx.fillStyle = i === 0 ? '#22c55e' : `hsl(${140-ratio*20}, ${80-ratio*20}%, ${45-ratio*20}%)`;
      if (i === 0) { pctx.shadowColor = '#22c55e'; pctx.shadowBlur = 10; }
      else pctx.shadowBlur = 0;
      pctx.beginPath();
      pctx.roundRect(seg.x*PGRID+1, seg.y*PGRID+1, PGRID-2, PGRID-2, i===0?4:2);
      pctx.fill();
    });
    pctx.shadowBlur = 0;

    // Score
    pctx.fillStyle = '#22c55e';
    pctx.font = '10px "Press Start 2P", monospace';
    pctx.textAlign = 'left';
    pctx.fillText('SCORE: ' + pScore, 6, 16);
  }

  function updatePreview() {
    pDir = getNextDir();
    const head = {x: pSnake[0].x+pDir.x, y: pSnake[0].y+pDir.y};

    // Reset if wall hit
    if (head.x<0||head.x>=PCOLS||head.y<0||head.y>=PROWS||pSnake.some(s=>s.x===head.x&&s.y===head.y)) {
      pSnake = [{x:10,y:10},{x:9,y:10},{x:8,y:10}];
      pDir = {x:1, y:0};
      pScore = 0;
      placePFood();
      return;
    }

    pSnake.unshift(head);
    if (head.x===pFood.x && head.y===pFood.y) {
      pScore += 10;
      placePFood();
    } else {
      pSnake.pop();
    }
    drawPreview();
  }

  drawPreview();
  setInterval(updatePreview, 130);
}
