============================================================
  SNAKE GAME — by Steven Valentius Young
  Website 3 Halaman | HTML + Bootstrap + JavaScript
============================================================

STRUKTUR FILE:
--------------
snake-game-steven/
│
├── index.html          --> Halaman 1: Landing Page (Promosi Game)
├── profile.html        --> Halaman 2: Halaman Main Game (Snake Game)
├── contact.html        --> Halaman 3: Halaman Feedback/Kontak
│
├── css/
│   └── style.css       --> Custom CSS (max 20% styling)
│
└── js/
    ├── main.js         --> JavaScript untuk Landing Page
    ├── profile.js      --> JavaScript untuk Snake Game (game engine)
    └── contact.js      --> JavaScript untuk Form Feedback (validasi)

------------------------------------------------------------
PENJELASAN MASING-MASING FILE:
------------------------------------------------------------

[ index.html ] — HALAMAN 1: LANDING PAGE
  - Bagian Navbar    : Navigasi ke 3 halaman
  - Bagian Hero      : Judul game, deskripsi, preview canvas otomatis
  - Bagian Fitur     : 4 fitur unggulan game (card Bootstrap)
  - Bagian Cara Main : 5 langkah cara bermain
  - Bagian Pembuat   : Info Steven Valentius Young
  - Bagian Stats     : Counter animasi (score, level, dll)
  - Bagian Footer    : Copyright

[ profile.html ] — HALAMAN 2: MAIN GAME
  - Bagian Navbar      : Navigasi ke 3 halaman
  - Bagian Scoreboard  : SCORE / BEST / LEVEL display
  - Bagian Canvas Game : Area bermain Snake Game (500x500px)
  - Bagian Kontrol     : Info tombol keyboard + tombol mobile
  - Bagian Tips        : Tips & Tricks bermain
  - Bagian Info        : Info pembuat game
  - Bagian Footer      : Copyright

[ contact.html ] — HALAMAN 3: FEEDBACK
  - Bagian Navbar       : Navigasi ke 3 halaman
  - Bagian Header       : Judul halaman feedback
  - Bagian Info Cards   : Email, GitHub, High Score Challenge
  - Bagian Form         : Form feedback dengan validasi JS
    * Field Nama        : Wajib diisi
    * Field Email       : Validasi format email
    * Field Jenis       : Dropdown pilihan jenis feedback
    * Field Best Score  : Input angka skor (opsional)
    * Field Pesan       : Textarea pesan (maks 500 karakter)
  - Bagian CTA          : Tombol kembali main game
  - Bagian Footer       : Copyright

[ css/style.css ] — CUSTOM CSS
  - @import font        : Google Fonts (Press Start 2P + Exo 2)
  - .hero-section       : Background radial gradient gelap
  - .hero-section::before : Efek scanline retro
  - .arcade-font        : Font pixel arcade
  - .text-snake         : Warna hijau dengan glow effect
  - .fade-in            : Animasi scroll masuk
  - #snakeCanvas        : Styling canvas game (border glow hijau)
  - .section-accent     : Garis dekoratif bawah judul
  - .feature-card:hover : Efek hover card
  - .avatar-ring        : Border foto profil
  - .blink              : Animasi kedip cursor
  - .score-ticker       : Font monospace untuk score

[ js/main.js ] — JAVASCRIPT LANDING PAGE
  - IntersectionObserver : Animasi fade-in saat scroll
  - animateCounter()     : Animasi counter angka di stats section
  - Preview Canvas AI    : Ular berjalan otomatis di hero section
    * getNextDir()       : AI sederhana mengejar makanan
    * drawPreview()      : Render canvas preview
    * updatePreview()    : Update state game preview

[ js/profile.js ] — JAVASCRIPT SNAKE GAME ENGINE
  - Konfigurasi        : GRID 20px, 25x25 kotak
  - initGame()         : Reset semua state game
  - placeFood()        : Menaruh makanan di posisi acak
  - update()           : Loop utama game (tiap interval)
    * Cek tabrakan dinding dan tubuh sendiri
    * Deteksi makan food
    * Update skor dan level
  - draw()             : Render semua elemen di canvas
    * Background + grid
    * Food dengan efek glow merah
    * Ular dengan efek glow hijau + mata
    * Overlay pause/game-over
  - drawIdle()         : Tampilan awal sebelum game mulai
  - drawGameOver()     : Tampilan game over dengan skor
  - startGame()        : Mulai/restart game
  - endGame()          : Akhiri game
  - togglePause()      : Pause dan resume game
  - Keyboard Controls  : Arrow Keys + WASD + Space
  - Mobile Buttons     : Tombol Up/Down/Left/Right layar sentuh
  - localStorage       : Menyimpan best score di browser

[ js/contact.js ] — JAVASCRIPT FORM VALIDASI
  - Character counter  : Hitung karakter pesan real-time
  - showError()        : Tampilkan pesan error di field
  - showValid()        : Tampilkan tanda valid di field
  - isValidEmail()     : Validasi format email dengan regex
  - validateField()    : Validasi tiap field saat blur/input
    * Nama: minimal 2 karakter
    * Email: format valid (regex)
    * Jenis: tidak boleh kosong
    * Pesan: 10-500 karakter
  - Form submit handler: Validasi semua + simulasi kirim
    * Loading spinner saat submit
    * Alert sukses setelah 1.5 detik
    * Reset form setelah berhasil

------------------------------------------------------------
CARA PENGGUNAAN:
------------------------------------------------------------
1. Buka file index.html di browser (Chrome/Firefox/Edge)
2. Navigasi ke halaman lain via navbar
3. Untuk bermain game: klik "Main Game" atau "Play Now"
4. Internet diperlukan untuk Bootstrap CDN dan Google Fonts

TEKNOLOGI:
  - HTML5          : Struktur halaman + Canvas API
  - Bootstrap 5.3  : 80%+ styling via CDN
  - CSS3           : Max 20% custom style
  - JavaScript ES6 : Game logic, animasi, validasi form
  - Google Fonts   : Press Start 2P + Exo 2

============================================================
  Dibuat oleh: Steven Valentius Young | 2024
============================================================
